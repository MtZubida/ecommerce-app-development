import Link from "next/link"
export default function Custom404() {


    return (
      <>
<h1>404</h1>
      <h1>This page does not exists</h1>

    <Link href="/">Go back HOME</Link>
      </>
    )
  }